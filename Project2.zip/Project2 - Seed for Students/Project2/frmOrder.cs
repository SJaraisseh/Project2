﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project2
{
    public partial class frmOrder : Form
    {
         // declare list that contains item prices
         List<double> ItemPrices = new List<double>();

         // declare list that contains order prices
         List<double> OrderPrices = new List<double>();

        public frmOrder()
        {
            InitializeComponent();

            ItemPrices.Add(4.95);
            ItemPrices.Add(6.87);
            ItemPrices.Add(8.52);
            ItemPrices.Add(2.99);
            ItemPrices.Add(0.71);
            ItemPrices.Add(0.50);
            ItemPrices.Add(0.99);
        }
        private void btnNew_Click(object sender, EventArgs e)
        {
            // clear order list box, clear out order list, clear labels
            ClearValues();
        }


        private void lstItems_DoubleClick(object sender, EventArgs e)
        {
            // validate item is selected
            if (lstItems.SelectedIndex > -1)
            {
                // get price/string value of selected item and add to order list
                AddOrder();               
                // display totals from calculation performing functions
                decimal dclSubtotal = (decimal)OrderPrices.Sum();
                decimal dclTax = CalcTax(dclSubtotal);
                decimal dclGrandTotal = dclSubtotal + dclTax;
                lblSubtotal.Text = dclSubtotal.ToString("N2");
                lblTax.Text = dclTax.ToString("N2");
                lblTotal.Text = dclGrandTotal.ToString("N2");
            }
        }

        private void lstOrder_DoubleClick(object sender, EventArgs e)
        {
            // validate item was selected
            if (lstOrder.SelectedIndex > -1)
            {
                // remove from list
                OrderPrices.RemoveAt(lstOrder.SelectedIndex);

                // remove from listbox
                lstOrder.Items.RemoveAt(lstOrder.SelectedIndex);

                // display totals from calculation performing functions
                decimal dclSubtotal = (decimal)OrderPrices.Sum();
                decimal dclTax = CalcTax(dclSubtotal);
                decimal dclGrandTotal = dclSubtotal + dclTax;
                lblSubtotal.Text = dclSubtotal.ToString("N2");
                lblTax.Text = dclTax.ToString("N2");
                lblTotal.Text = dclGrandTotal.ToString("N2");
            }
           
        }
        private void ClearValues ()
        {
            OrderPrices.Clear();
            lstItems.SelectedIndex = -1;
            lstOrder.Items.Clear();
            lblSubtotal.Text = "0.00";
            lblTax.Text = "0.00";
            lblTotal.Text = "0.00";
        }
        private decimal CalcTax (decimal Subtotal)
        {
            return Subtotal * 6 / 100;
        }
        private void AddOrder()
        {
            // get price/name of selected item and add to order list
            if (lstItems.SelectedIndex == 0)
            {
                OrderPrices.Add(ItemPrices[0]);
                lstOrder.Items.Add("Small Coffee");
            }
            else if (lstItems.SelectedIndex == 1)
            {
                OrderPrices.Add(ItemPrices[1]);
                lstOrder.Items.Add("Medium Coffee");
            }
            else if (lstItems.SelectedIndex == 2)
            {
                OrderPrices.Add(ItemPrices[2]);
                lstOrder.Items.Add("Large Coffee");
            }
            else if (lstItems.SelectedIndex == 3)
            {
                OrderPrices.Add(ItemPrices[3]);
                lstOrder.Items.Add("Bagel");
            }
            else if (lstItems.SelectedIndex == 4)
            {
                OrderPrices.Add(ItemPrices[4]);
                lstOrder.Items.Add("Cream");
            }
            else if (lstItems.SelectedIndex == 5)
            {
                OrderPrices.Add(ItemPrices[5]);
                lstOrder.Items.Add("Sugar");
            }
            else
            {
                OrderPrices.Add(ItemPrices[6]);
                lstOrder.Items.Add("Lid");
            }
        }
    }
}
